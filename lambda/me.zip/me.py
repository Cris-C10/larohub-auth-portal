import json
import base64
import urllib.request
import time
import jwt

def _fetch_jwks() -> dict:
    url = "https://cognito-idp.eu-west-2.amazonaws.com/eu-west-2_MijIHDVyZ/.well-known/jwks.json"
    with urllib.request.urlopen(url) as response:
        return json.loads(response.read().decode("utf-8"))

def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)

def _get_cookie(event: dict, name: str) -> str | None:
    # HTTP API v2 often provides cookies here:
    cookie_list = event.get("cookies")
    if isinstance(cookie_list, list):
        for c in cookie_list:
            if c.startswith(name + "="):
                return c.split("=", 1)[1]

    # Fallback: sometimes still present in headers
    headers = event.get("headers") or {}
    cookie_header = headers.get("cookie") or headers.get("Cookie") or ""
    if cookie_header:
        for p in cookie_header.split(";"):
            p = p.strip()
            if p.startswith(name + "="):
                return p.split("=", 1)[1]

    return None


def handler(event, context):
    token = _get_cookie(event, "larohub_id_token")

    if not token:
        return {
            "statusCode": 401,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"authenticated": False, "reason": "missing_cookie"})
        }

    parts = token.split(".")
    if len(parts) != 3:
        return {
            "statusCode": 401,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"authenticated": False, "reason": "invalid_jwt_format"})
        }

    header_b64, payload_b64, signature_b64 = parts
    payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))

    if payload.get("iss") != "https://cognito-idp.eu-west-2.amazonaws.com/eu-west-2_MijIHDVyZ":
        return {
            "statusCode": 401,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"authenticated": False, "reason": "invalid_issuer"})
        }

    if payload.get("aud") != "u2qtjnkdgqppsv2u44latqf76":
        return {
            "statusCode": 401,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"authenticated": False, "reason": "invalid_audience"})
        }

    if payload.get("exp", 0) < int(time.time()):
        return {
            "statusCode": 401,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"authenticated": False, "reason": "token_expired"})
        }

    try:
        header = json.loads(_b64url_decode(header_b64).decode("utf-8"))
        kid = header.get("kid")

        if not kid:
            return {
                "statusCode": 401,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"authenticated": False, "reason": "missing_kid"})
            }

        try:
            jwks = _fetch_jwks()
        except Exception:
            return {
                "statusCode": 401,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"authenticated": False, "reason": "jwks_fetch_failed"})
            }

        key = None
        for k in jwks.get("keys", []):
            if k.get("kid") == kid:
                key = k
                break

        if not key:
            return {
                "statusCode": 401,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"authenticated": False, "reason": "jwks_key_not_found"})
            }

        public_key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(key))

        try:
            decoded = jwt.decode(
                token,
                public_key,
                algorithms=["RS256"],
                audience="u2qtjnkdgqppsv2u44latqf76",
                issuer="https://cognito-idp.eu-west-2.amazonaws.com/eu-west-2_MijIHDVyZ"
            )
        except Exception:
            return {
                "statusCode": 401,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"authenticated": False, "reason": "invalid_signature"})
            }

    except Exception:
        return {
            "statusCode": 401,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"authenticated": False, "reason": "invalid_jwt_header"})
        }

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"authenticated": True, "stage": "jwt_signature_valid"})
    }